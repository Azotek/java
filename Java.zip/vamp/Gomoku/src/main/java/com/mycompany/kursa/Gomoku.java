/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.kursa;

import java.awt.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;    

/**
  * Эта панель позволяет двум пользователям играть в Го Моку против друг
  * друга. Черные всегда начинают игру. Когда у игрока получается пять фигур подряд,
  * этот игрок выигрывает. Игра заканчивается ничьей, если доска заполнена
  * до победы любого из игроков.
  */

public class Gomoku extends JPanel {
    
    
    private static Socket clientSocket; //сокет для общения
    private static BufferedReader in; // поток чтения из сокета
    private static BufferedWriter out; // поток записи в сокет
   
   /**
     * Основная процедура позволяет запускать GoMoku как 
     * отдельное приложение. Открывается окно с игрой; программа
     * заканчивается, когда пользователь закрывает окно.
     */
   public static void main(String[] args) {
        try {
            clientSocket = new Socket("localhost", 4004); // этой строкой мы запрашиваем
            in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
            JFrame window = new JFrame("Пять в ряд");
            Gomoku content = new Gomoku();
            window.setContentPane(content);
            window.pack();
            Dimension screensize = Toolkit.getDefaultToolkit().getScreenSize();
            window.setLocation( (screensize.width - window.getWidth())/2,
                    (screensize.height - window.getHeight())/2 );
            window.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
            window.setResizable(false);
            window.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(Gomoku.class.getName()).log(Level.SEVERE, null, ex);
        }
   }
   

   private JButton newGameButton;  // Кнопка для новой игры.

   private JButton resignButton;   // Кнопка, которая позволяет игроку  сдаться.
                                    
   private JButton endGameButton;
   
   private JLabel message;  // Отображение сообщения пользователю.
   
   
   public Gomoku() {
      
      setLayout(null);  // Создание игрового поля
      
      setPreferredSize( new Dimension(350,250) );
      
      setBackground(new Color(71,234,180)); 
      
      /* Создание компонентов и отображение их в панели */
      
      Board board = new Board();  
      add(board);
      add(newGameButton);
      add(resignButton);
      add(endGameButton);
      add(message);
      
      board.setBounds(16,16,172,172); 
      newGameButton.setBounds(210, 30, 120, 30);
      resignButton.setBounds(210, 90, 120, 30);
      endGameButton.setBounds(210, 150, 120, 30);
      message.setBounds(0, 200, 350, 30);
   }
   
   
   // ----------------------- Вложенный класс -----------------------------------
   
   class Board extends JPanel implements ActionListener, MouseListener {
      
      int[][] board;   
      
      static final int EMPTY = 0,       // Пустая клетка.
                       WHITE = 1,       // Белая фигура.
                       BLACK = 2;       // Чёрная фигура.
      
      boolean gameInProgress; // Запущена ли игра
      
      int currentPlayer;      // Чей ход.  Возможные значения черный или белый
                              // Работает только если игра запущена
      
      int win_r1, win_c1, win_r2, win_c2;  // Когда игрок получает 5 или более
                                           // фигур подряд, ячейки определяются
                                           // (win_r1,win_c1) и (win_r2,win_c2)
                                           // Красная линия рисуется между этими
                                           // ячейками.  Если 5 фигур подряд нет
                                           // значение win_r1 устанавливается -1.
                                           // 
      
      /**
       * Конструктор.  Создает кнопки и метки. Реагирует на
       * нажатие мыши. Создаёт игровое поле и начинает игру.
       */
      public Board() {
         setBackground(Color.LIGHT_GRAY);
         addMouseListener(this);
         resignButton = new JButton("Сдаться");
         resignButton.addActionListener(this);
         newGameButton = new JButton("Новая игра");
         newGameButton.addActionListener(this);
         endGameButton = new JButton("Выход");
         endGameButton.addActionListener(this);
         message = new JLabel("",JLabel.CENTER);
         message.setFont(new  Font("Bahnschrift SemiBold", Font.BOLD, 14));
         message.setForeground(Color.BLACK);
         board = new int[13][13];
         doNewGame();
      }
      

      /**
       * Реагирует на нажатие одной из кнопок пользователем.
       */
      public void actionPerformed(ActionEvent evt) {
         Object src = evt.getSource();
         if (src == newGameButton)
            doNewGame();
         else if (src == resignButton)
            doResign();
         else if (src == endGameButton){
             try {
                 send("exit");
                 clientSocket.close();
                 in.close();
                 out.close();
                 System.exit(0);
             } catch (IOException ex) {
                 Logger.getLogger(Gomoku.class.getName()).log(Level.SEVERE, null, ex);
             }
         }
      }
      
      
      /**
       * Начало новой игры;
       * Когда пользователь нажимает "Новая игра".
       */
      void doNewGame() {
         send("StartGame");
         for (int row = 0; row < 13; row++)       // Заполняет игровое поле пустыми ячейками
            for (int col = 0; col < 13; col++)
               board[row][col] = EMPTY;
         currentPlayer = BLACK;   // Чёрный ходит первым.
         message.setText("Чёрный: Твой ход! ");
         gameInProgress = true;
         newGameButton.setEnabled(false);
         resignButton.setEnabled(true);
         win_r1 = -1; 
         repaint();
      }
      
       // Текущий игрок сдаётся;
      void doResign() {
         
         if (currentPlayer == WHITE){
            message.setText("Белый сдаётся. Чёрный победил!");
            send("BlackWin");
                    }
         else{
            message.setText("Чёрный сдаётся. Белый победил!");
            send("WhiteWin");
         }
         newGameButton.setEnabled(true);
         resignButton.setEnabled(false);
         gameInProgress = false;
      }
      
      
      /**
       * Когда игра заканчивается.  Параметр str
       * отображается как сообщение, и кнопки неактивны.
       * Игра не запущена.
       */
      void gameOver(String str) {
         message.setText(str);
         newGameButton.setEnabled(true);
         resignButton.setEnabled(false);
         gameInProgress = false;
      }
      
      void doClickSquare(int row, int col) {
         
         /* Проверка клетки, если пользователь нажал на заполненую
            клетку, выдает сообщение об ошибке
          */
         
         if ( board[row][col] != EMPTY ) {
            if (currentPlayer == BLACK)
               message.setText("Чёрный: Нажми на свободную клетку.");
            else
               message.setText("Белый:  Нажми на свободную клетку.");
            return;
         }
         
         /* Проверка заполнена ли всё игровое поле или сдедующий ход
          выигрышный. Если так, то игра заканчивается.  Если нет,
          Ход переходит к другому игроку */
         
         board[row][col] = currentPlayer;  // Сделать ход
         repaint();
         
         if (winner(row,col)) {  // Проверка на победителя
            if (currentPlayer == WHITE){
               gameOver("Белый победил!");
               send("WhiteWin");
            }
            else{
               gameOver("Чёрный победил!");
               send("BlackWin");
            }
            return;
         }
         
         boolean emptySpace = false;     // Проверка на заполненность игрового поля.
         for (int i = 0; i < 13; i++)
            for (int j = 0; j < 13; j++)
               if (board[i][j] == EMPTY)
                  emptySpace = true;
         if (emptySpace == false) {
            gameOver("Ничья!");
            send("draw");
            return;
         }
         
         /* Продолжение игры. Ход следующего игрока */
         
         if (currentPlayer == BLACK) {
            currentPlayer = WHITE;
            send("BlackStep");
            message.setText("Белый:  Твой ход! ");
         }
         else {  
            currentPlayer = BLACK;
            send("WhiteStep");
            message.setText("Чёрный: Твой ход! ");
         }
         
      }  
      
      
      /**
       * Вызывается после каждого хода игрока
       * Определяет, выигрышный ли ход подсчитывая количество
       * заполненных ячеек в линии во всех направлениях
       * (row,col).  Если заполнено 5 или более
       * ячеек подряд, то игра заканчивается
       */
      private boolean winner(int row, int col) {
         
         if (count( board[row][col], row, col, 1, 0 ) >= 5)
            return true;
         if (count( board[row][col], row, col, 0, 1 ) >= 5)
            return true;
         if (count( board[row][col], row, col, 1, -1 ) >= 5)
            return true;
         if (count( board[row][col], row, col, 1, 1 ) >= 5)
            return true;
         
         /*Игра не выиграна*/
         
         win_r1 = -1;
         return false;
         
      }  
      
      private int count(int player, int row, int col, int dirX, int dirY) {
         
         int ct = 1;  //Количество ячеек подряд у игрока.
         
         int r, c;    
         
         r = row + dirX; 
         c = col + dirY;
         while ( r >= 0 && r < 13 && c >= 0 && c < 13 && board[r][c] == player ) {
            // Ячейка игрового поля заполнена одним из игроков
            ct++;
            r += dirX;  //Переместиться к следующей ячейке
            c += dirY;
         }
         
         win_r1 = r - dirX;  
         win_c1 = c - dirY;  // Последняя просмотренная ячейка вне игрового поля 
         // или не содержит фигур ни одного из игроков.
         
         r = row - dirX; 
         c = col - dirY;
         while ( r >= 0 && r < 13 && c >= 0 && c < 13 && board[r][c] == player ) {
            // Ячейка в игровом поле и содержит фигуру одного из игроков.
            ct++;
            r -= dirX;   // Переместиться к следующей ячейке
            c -= dirY;
         }
         
         win_r2 = r + dirX;
         win_c2 = c + dirY;
         
         // В этом случае, (win_r1,win_c1) и (win_r2,win_c2) отмечают конечные точки
         // линии с фигурой одного из игроков.
         
         return ct;
         
      }  
      
      
      /**
       * Изображение игрового поля и фигур.  Если игра выиграна,
       * рисует красную линию по фигурам
       */
      public void paintComponent(Graphics g) {
         
         super.paintComponent(g); 
         
         g.setColor(Color.DARK_GRAY);
         for (int i = 1; i < 13; i++) {
            g.drawLine(1 + 13*i, 0, 1 + 13*i, getSize().height);
            g.drawLine(0, 1 + 13*i, getSize().width, 1 + 13*i);
         }
         g.setColor(Color.BLACK);
         g.drawRect(0,0,getSize().width-1,getSize().height-1);
         g.drawRect(1,1,getSize().width-3,getSize().height-3);
         
         /* Фигура в игровом поле */
         
         for (int row = 0; row < 13; row++)
            for (int col = 0; col < 13; col++)
               if (board[row][col] != EMPTY)
                  drawPiece(g, board[row][col], row, col);
         
         /* Если игры была выиграна, win_r1 >= 0.  Рисует красную линию
          по выигрышным фигурами */
         
         if (win_r1 >= 0)
            drawWinLine(g);
         
      } 
      
      
      /**
       * Отображение фигуры в ячейке (row,col).  Цвет выбирается по 
       * параметру, который установлен как BLACK или WHITE.
       */
      private void drawPiece(Graphics g, int piece, int row, int col) {
         if (piece == WHITE)
            g.setColor(Color.WHITE);
         else
            g.setColor(Color.BLACK);
         g.fillOval(3 + 13*col, 3 + 13*row, 10, 10);
      }
      
       // Рисует красную линию из (win_r1,win_c1) в (win_r2,win_c2)
      private void drawWinLine(Graphics g) {
         g.setColor(Color.RED);
         g.drawLine( 8 + 13*win_c1, 8 + 13*win_r1, 8 + 13*win_c2, 8 + 13*win_r2 );
         if (win_r1 == win_r2)
            g.drawLine( 8 + 13*win_c1, 7 + 13*win_r1, 8 + 13*win_c2, 7 + 13*win_r2 );
         else
            g.drawLine( 7 + 13*win_c1, 8 + 13*win_r1, 7 + 13*win_c2, 8 + 13*win_r2 );
      }
      
      
      /**
       * Реагирует на нажатие игрока по игровому полю.
       * Если игра не запущена, выдаёт ошибку. Иначе ищет строку и столбец
       * куда нажал игрок и вызывает doClickSquare()
       */
      public void mousePressed(MouseEvent evt) {
         if (gameInProgress == false)
            message.setText("Нажми \"Новая игра\" чтобы начать игру.");
         else {
            int col = (evt.getX() - 2) / 13;
            int row = (evt.getY() - 2) / 13;
            if (col >= 0 && col < 13 && row >= 0 && row < 13)
               doClickSquare(row,col);
         }
      }
      private void send(String msg) {
    try {
        out.write(msg + "\n");
        out.flush();
    } catch (IOException ignored) {}
}
      
      
      public void mouseReleased(MouseEvent evt) { }
      public void mouseClicked(MouseEvent evt) { }
      public void mouseEntered(MouseEvent evt) { }
      public void mouseExited(MouseEvent evt) { }
      
      
   }
   
   
   
}
